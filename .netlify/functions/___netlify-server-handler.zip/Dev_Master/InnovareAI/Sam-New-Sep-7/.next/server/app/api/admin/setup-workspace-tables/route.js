(()=>{var a={};a.id=1321,a.ids=[1321],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3279:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>C,patchFetch:()=>B,routeModule:()=>x,serverHooks:()=>A,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>z});var d={};c.r(d),c.d(d,{POST:()=>w});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(82461),v=c(10641);async function w(a){try{let a=process.env.SUPABASE_SERVICE_ROLE_KEY,b=(0,u.UU)("https://latxadqrvrrrcvkktrog.supabase.co",a),c=[];try{let{error:a}=await b.rpc("exec_sql",{query:`
          CREATE TABLE IF NOT EXISTS workspaces (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            name TEXT NOT NULL,
            owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
            created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
            company TEXT DEFAULT 'InnovareAI' CHECK (company IN ('InnovareAI', '3cubedai')),
            settings JSONB DEFAULT '{}',
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
          );
        `});c.push({table:"workspaces",success:!a,error:a?.message})}catch(a){c.push({table:"workspaces",success:!1,error:a instanceof Error?a.message:"Unknown error"})}try{let{error:a}=await b.rpc("exec_sql",{query:`
          CREATE TABLE IF NOT EXISTS workspace_members (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
            user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
            role TEXT DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
            joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            invited_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
            UNIQUE(workspace_id, user_id)
          );
        `});c.push({table:"workspace_members",success:!a,error:a?.message})}catch(a){c.push({table:"workspace_members",success:!1,error:a instanceof Error?a.message:"Unknown error"})}try{let{error:a}=await b.rpc("exec_sql",{query:`
          CREATE INDEX IF NOT EXISTS idx_workspaces_owner ON workspaces(owner_id);
          CREATE INDEX IF NOT EXISTS idx_workspaces_company ON workspaces(company);
          CREATE INDEX IF NOT EXISTS idx_workspace_members_workspace ON workspace_members(workspace_id);
          CREATE INDEX IF NOT EXISTS idx_workspace_members_user ON workspace_members(user_id);
        `});c.push({table:"indexes",success:!a,error:a?.message})}catch(a){c.push({table:"indexes",success:!1,error:a instanceof Error?a.message:"Unknown error"})}try{let{error:a}=await b.rpc("exec_sql",{query:`
          ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;
          ALTER TABLE workspace_members ENABLE ROW LEVEL SECURITY;
        `});c.push({table:"rls_enable",success:!a,error:a?.message})}catch(a){c.push({table:"rls_enable",success:!1,error:a instanceof Error?a.message:"Unknown error"})}try{let{error:a}=await b.rpc("exec_sql",{query:`
          DROP POLICY IF EXISTS "Users can access workspaces they own or are members of" ON workspaces;
          DROP POLICY IF EXISTS "Super admins can manage all workspaces" ON workspaces;
          DROP POLICY IF EXISTS "Users can manage workspace members" ON workspace_members;
          DROP POLICY IF EXISTS "Super admins can manage all workspace members" ON workspace_members;
          
          CREATE POLICY "Users can access workspaces they own or are members of"
            ON workspaces FOR SELECT
            USING (
              owner_id = auth.uid() OR 
              id IN (
                SELECT workspace_id FROM workspace_members 
                WHERE user_id = auth.uid()
              )
            );

          CREATE POLICY "Users can manage their own workspaces"
            ON workspaces FOR ALL
            USING (owner_id = auth.uid());

          CREATE POLICY "Super admins can manage all workspaces"
            ON workspaces FOR ALL
            USING (
              auth.email() IN ('tl@innovareai.com', 'cl@innovareai.com')
            );

          CREATE POLICY "Users can manage workspace members"
            ON workspace_members FOR ALL
            USING (
              workspace_id IN (
                SELECT id FROM workspaces WHERE owner_id = auth.uid()
              )
            );

          CREATE POLICY "Super admins can manage all workspace members"
            ON workspace_members FOR ALL
            USING (
              auth.email() IN ('tl@innovareai.com', 'cl@innovareai.com')
            );
        `});c.push({table:"rls_policies",success:!a,error:a?.message})}catch(a){c.push({table:"rls_policies",success:!1,error:a instanceof Error?a.message:"Unknown error"})}let d=c.filter(a=>a.success).length,e=c.length;return v.NextResponse.json({success:d===e,message:`Database setup completed: ${d}/${e} operations successful`,timestamp:new Date().toISOString(),results:c})}catch(a){return console.error("Database setup error:",a),v.NextResponse.json({error:"Internal server error",details:a instanceof Error?a.message:"Unknown error"},{status:500})}}let x=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/admin/setup-workspace-tables/route",pathname:"/api/admin/setup-workspace-tables",filename:"route",bundlePath:"app/api/admin/setup-workspace-tables/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/Users/tvonlinz/Dev_Master/InnovareAI/Sam-New-Sep-7/app/api/admin/setup-workspace-tables/route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:y,workUnitAsyncStorage:z,serverHooks:A}=x;function B(){return(0,g.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:z})}async function C(a,b,c){var d;let e="/api/admin/setup-workspace-tables/route";"/index"===e&&(e="/");let g=await x.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:y,prerenderManifest:z,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(z.dynamicRoutes[E]||z.routes[D]);if(F&&!y){let a=!!z.routes[D],b=z.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||x.isDev||y||(G="/index"===(G=D)?"/":G);let H=!0===x.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:z,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>x.onRequestError(a,b,d,A)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>x.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await x.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},A),b}},l=await x.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),y&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(L||b instanceof s.NoFallbackError||await x.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11997:a=>{"use strict";a.exports=require("punycode")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},27910:a=>{"use strict";a.exports=require("stream")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55591:a=>{"use strict";a.exports=require("https")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:a=>{"use strict";a.exports=require("zlib")},78335:()=>{},79551:a=>{"use strict";a.exports=require("url")},81630:a=>{"use strict";a.exports=require("http")},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96487:()=>{}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[4586,1692,4842],()=>b(b.s=3279));module.exports=c})();